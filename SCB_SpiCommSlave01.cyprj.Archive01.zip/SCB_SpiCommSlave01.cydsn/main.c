/*******************************************************************************
* File Name: main.c
*
* Version: 1.0
*
* Description:
*  This example project demonstrates the use of an SCB-based SPI slave
*  component. The SCB SPI slave communicates with a UDB-based SPI master,
*  located on the same PSoC but wired together externally. The SPI slave
*  receives a packet with a command from the SPI master to control the
*  RGB LED color. Once the slave updates the LED color, it returns a status
*  packet to the master.
*
********************************************************************************
* Copyright 2015, Cypress Semiconductor Corporation. All rights reserved.
* This software is owned by Cypress Semiconductor Corporation and is protected
* by and subject to worldwide patent and copyright laws and treaties.
* Therefore, you may use this software only as provided in the license agreement
* accompanying the software package from which you obtained this software.
* CYPRESS AND ITS SUPPLIERS MAKE NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* WITH REGARD TO THIS SOFTWARE, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT,
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*******************************************************************************/

#include <main.h>
#include <stdio.h>

/* For GCC compiler revise _write() function for printf functionality */
int _write(int file, char *ptr, int len)
{
    int i;
    file = file;
    for (i = 0; i < len; i++)
    {
        UART_UartPutChar(*ptr++);
    }
    return len;
}



/* SPIS functions */
static uint32 SPIS_WaitForCommand(void);
static void SPIS_UpdateStatus(uint32 status);
static void SPIS_CleanupAfterRead(void);

/* Executes command and returns status */
static uint8 ExecuteCommand(uint32 cmd);

/* This dummy buffer used by SPIM when it receives status packet.
* This dummy buffer used by SPIS when it receives command packet.
*/
const uint8 dummyBuffer[4] = {0xFFu, 0xFFu, 0xFFu, 0xffu};
uint8 cmd1;
uint8 tmpBuffer[4];

/*******************************************************************************
* Function Name: main
********************************************************************************
* Summary:
*  The main function performs the following actions:
*   1. Turns off RGB LED.
*   2. Sets up SPIS and SPIM components.
*   3. Enables global interrupts.
*   4. SPI master (SPIM) sends command to the SPI slave (SPIS) to control
*      RGB LED.
*   5. SPIS receives the command, updates the LED and returns a status packet.
*   6. SPIM receives the response status packet. If successful, increment to
*      next command. Otherwise send the same command until successful.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
int main()
{
    uint32 cmd;
    uint32 status;

    /* Start SPIS components operation */
    SPIS_Start();

    UART_Start();
    printf("slave Application started\r\n");

    CyGlobalIntEnable;



    /* Put data into the slave TX buffer to be transferred while following
    * master access.
    */
    //SPIS_UpdateStatus(0);

    for(;;)
    {
        

        /* Wait for the command from the master, execute it and update status */
        cmd = SPIS_WaitForCommand();
        status = ExecuteCommand(cmd);
        //SPIS_UpdateStatus(0);

        

        /* Clear slave buffer after response has been read */
        //SPIS_CleanupAfterRead();

        /* Delay between commands */
        CyDelay(10);
    }
}


/*******************************************************************************
* Function Name: SPIS_WaitForCommand
********************************************************************************
* Summary:
*  SPIS waits for completion of the transfer initiated by the SPIM. After packet
*  reception the format of the packet is verified and the command is returned.
*  If the format of the packet is invalid the unknown command is returned.
*
* Parameters:
*  None
*
* Return:
*  Returns command from the received packet.
*
*******************************************************************************/
static uint32 SPIS_WaitForCommand(void)
{
    
    uint32 cmd;
    uint32 i;

    /* Wait for the end of the transfer */
    while (4 != SPIS_SpiUartGetRxBufferSize())
    {
    }

    /* Read packet from the buffer */
    i = 0u;
    while (0u != SPIS_SpiUartGetRxBufferSize())
    {
        tmpBuffer[i] = SPIS_SpiUartReadRxData();
        i++;
    }

    /* Check start and end of packet markers */
    if ((tmpBuffer[0] == PACKET_SOP) &&
        (tmpBuffer[3] == PACKET_EOP))
    {
        /* Return command */
        cmd = tmpBuffer[PACKET_CMD_POS];
    }
    else
    {
        /* Incorrect packet format, return unknown command */
        cmd = CMD_SET_UNKNOWN;
    }

    return (cmd);
}


/*******************************************************************************
* Function Name: SPIS_CleanupAfterRead
********************************************************************************
* Summary:
*  SPIS waits for completion of the read transfer initiated by the SPIM. The
*  received packet is discarded as it contains only dummy data. Then the SPIS
*  prepares for the following command packet by putting dummy bytes into the
*  TX buffer.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
static void SPIS_CleanupAfterRead(void)
{
    /* Wait for the end of the transfer */
    while (4 != SPIS_SpiUartGetRxBufferSize())
    {
    }

    /* Clear RX buffer from dummy bytes */
    SPIS_SpiUartClearRxBuffer();

    /* Put dummy data into TX buffer to be transmitted to SPIM */
    SPIS_SpiUartPutArray(dummyBuffer, 4);
}


/*******************************************************************************
* Function Name: SPIS_UpdateStatus
********************************************************************************
* Summary:
*  SPIS copies packet with response into the buffer.
*
* Parameters:
*  status - status to insert into the response packet.
*
* Return:
*  None
*
*******************************************************************************/
static void SPIS_UpdateStatus(uint32 status)
{
    static uint8 sTxBuffer[4] = {PACKET_SOP, STS_CMD_FAIL, 0, PACKET_EOP};

    sTxBuffer[1] = (uint8) status;

    /* Put data into the slave TX buffer to be transferred while following
    * master access.
    */
    SPIS_SpiUartPutArray(sTxBuffer, 4);
}


/*******************************************************************************
* Function Name: ExecuteCommand
********************************************************************************
* Summary:
*  Executes received command to control the LED color and returns status.
*  If the command is unknown, the LED color is not changed.
*
* Parameters:
*  cmd: command to execute. Available commands:
*   - CMD_SET_RED:   set red color of the LED.
*   - CMD_SET_GREEN: set green color of the LED.
*   - CMD_SET_BLUE:  set blue color of the LED.
*   - CMD_SET_OFF:   turn off the LED.
*
* Return:
*  Returns status of command execution. There are two statuses
*  - STS_CMD_DONE: command is executed successfully.
*  - STS_CMD_FAIL: unknown command
*
*******************************************************************************/
static uint8 ExecuteCommand(uint32 cmd)
{
    uint8 status;

    status = STS_CMD_DONE;
    cmd1 = cmd;
    printf("    cmd1 and data: %d %d\r\n",
                        cmd1, tmpBuffer[2]);

    return (status);
}


/* [] END OF FILE */

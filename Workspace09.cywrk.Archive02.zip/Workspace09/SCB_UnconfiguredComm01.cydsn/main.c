/*******************************************************************************
* File Name: main.c
*
* Version: 1.10
*
* Description:
*  This example project demonstrates capability of the SCB component to be
*  reconfigured between multiple communication interfaces during run time.
*  This is done using the Unconfigured mode of the SCB component.
*  In this example, the component switches between SPI and UART modes to
*  execute example projects using a shared pair of communication IO’s.
*
********************************************************************************
* Copyright 2015, Cypress Semiconductor Corporation. All rights reserved.
* This software is owned by Cypress Semiconductor Corporation and is protected
* by and subject to worldwide patent and copyright laws and treaties.
* Therefore, you may use this software only as provided in the license agreement
* accompanying the software package from which you obtained this software.
* CYPRESS AND ITS SUPPLIERS MAKE NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* WITH REGARD TO THIS SOFTWARE, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT,
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*******************************************************************************/

#include <main.h>

/*******************************************************************************
* Function Prototypes
*******************************************************************************/
static cystatus ConfigurationChange(uint32 opMode);
static void RunSPIExample(void);
static void RunUartExample(void);
static uint32 ReadSwSwitch(void);
static uint8 ExecuteCommand(uint32 cmd);

#include <stdio.h>

/* For GCC compiler revise _write() function for printf functionality */
int _write(int file, char *ptr, int len)
{
    int i;
    file = file;
    for (i = 0; i < len; i++)
    {
        Comm_UartPutChar(*ptr++);
    }
    return len;
}


/*******************************************************************************
* Common Definitions
*******************************************************************************/
/* Constants */
#define ENABLED         (1u)
#define DISABLED        (0u)
#define NON_APPLICABLE  (DISABLED)

/* Common RX and TX buffers for I2C and UART operation */
#define COMMON_BUFFER_SIZE     (16u)
uint8 bufferTx[COMMON_BUFFER_SIZE];

/* UART RX buffer requires one extra element for proper operation. One element
* remains empty while operation. Keeping this element empty simplifies
* circular buffer operation.
*/
uint8 bufferRx[COMMON_BUFFER_SIZE + 1u];


uint8 data = 0;

/*******************************************************************************
* UART Configuration
*******************************************************************************/
#define UART_OVERSAMPLING       (13u)
#define UART_DATA_WIDTH         (8u)
#define UART_RX_INTR_MASK       (Comm_INTR_RX_NOT_EMPTY)
#define UART_TX_INTR_MASK       (0u)

#define UART_RX_BUFFER_SIZE     (COMMON_BUFFER_SIZE)
#define UART_TX_BUFFER_SIZE     (COMMON_BUFFER_SIZE)
#define UART_RX_BUFER_PTR       bufferRx
#define UART_TX_BUFER_PTR       bufferTx

#define SPI_RX_BUFFER_SIZE     (COMMON_BUFFER_SIZE)
#define SPI_TX_BUFFER_SIZE     (COMMON_BUFFER_SIZE)
#define SPI_RX_BUFER_PTR       bufferRx
#define SPI_TX_BUFER_PTR       bufferTx

/* UART desired baud rate is 115200 bps. The selected Oversampling parameter is
* 16. The CommCLK = Baud rate * Oversampling = 115200 * 13 = 1.4976 MHz.
* The clock divider has to be calculated to control clock frequency as clock
* component provides interface to it.
* Divider = (HFCLK / CommCLK) = (24 MHz / 1.4976 MHz) = 16. But the devider 
* value written into the register has to decremented by 1 therefore end value 
* is 15.
* The clock accuracy is important for UART operation. The actual CommCLK equal:
* CommCLK(actual) = (24 MHz / 16) = 1.5 MHz
* The deviation of actual CommCLK from desired must be calculated:
* Deviation = (1.5 MHz – 1.4976 MHz) / 1.4976 MHz = ~0.16%
* Taking into account HFCLK accuracy ±2%, the total error is:0.2 + 0.16 = 2.16%.
* The total error value is less than 5% and it is enough for correct
* UART operation.
* The divider to create CommCLK for HFCLK = 12 MHz is two times less than for 
* HFCLK = 24 MHz and equal to 8. The value written into the register is 7.
*/
/* SPI desired baud rate is 1Mps. The selected Oversampling parameter is
* 8. The CommCLK = mbps * Oversampling = 1 * 8 = 8 MHz.
* The clock divider has to be calculated to control clock frequency as clock
* component provides interface to it.
* Divider = (HFCLK / CommCLK) = (24 MHz / 8 MHz) = 3. But the devider 
* value written into the register has to decremented by 1 therefore end value 
* is 2.

* The divider to create CommCLK for HFCLK = 12 MHz is two times less than for 
* HFCLK = 24 MHz and equal to 1.5. The value written into the register is 1.
*/
#if (24u == CYDEV_BCLK__HFCLK__MHZ)
    #define UART_CLK_DIVIDER        (15u)
    #define SPI_CLK_DIVIDER         (2u)
#elif (12u == CYDEV_BCLK__HFCLK__MHZ)
    #define UART_CLK_DIVIDER        (7u)
    #define SPI_CLK_DIVIDER         (1u)
#else
    #error For correct SCB_UnconfiguredComm code example operation the HFCLK \
           frequency must be 24 or 12 MHz. Open Design Wide Resources file   \
           Clocks tab and change HFCLK to match requirement.
    
    #define UART_CLK_DIVIDER        (0u)
#endif /* (24u == CYDEV_BCLK__HFCLK__MHZ) */


#define SPI_INTERRUPT_MODE         (0u)

#define SPI_INTR_RX_MASK           (0u)
#define SPI_INTR_TX_MASK           (0u)

#define SPI_RX_TRIGGER_LEVEL       (15u)
#define SPI_TX_TRIGGER_LEVEL       (0u)

#define SPI_BYTE_MODE_ENABLE       (0u)
#define SPI_FREE_RUN_SCLK_ENABLE   (0u)
#define SPI_SS0_POLARITY           (0u)
#define SPI_OVS_FACTOR             (8)


/* Comm_SPI_INIT_STRUCT provides the fields which match the selections
* available in the customizer. Refer to the spi customizer for detailed
* description of the settings.
*/
const Comm_SPI_INIT_STRUCT configSpi = 
{
    Comm_SPI_MASTER,
    Comm_SPI_MODE_MOTOROLA,
    Comm_SPI_SCLK_CPHA0_CPOL0,
    SPI_OVS_FACTOR,
    Comm_SPI_MEDIAN_FILTER_ENABLE,
    Comm_SPI_LATE_MISO_SAMPLE_ENABLE,
    Comm_SPI_WAKE_ENABLE,
    Comm_SPI_RX_DATA_BITS_NUM,
    Comm_SPI_TX_DATA_BITS_NUM,
    Comm_SPI_BITS_ORDER,
    Comm_SPI_TRANSFER_SEPARATION,
    SPI_RX_BUFFER_SIZE,
    SPI_RX_BUFER_PTR,
    SPI_TX_BUFFER_SIZE,
    SPI_TX_BUFER_PTR,
    SPI_INTERRUPT_MODE,
    SPI_INTR_RX_MASK,
    SPI_RX_TRIGGER_LEVEL,
    SPI_INTR_TX_MASK,
    SPI_TX_TRIGGER_LEVEL,
    SPI_BYTE_MODE_ENABLE,
    SPI_FREE_RUN_SCLK_ENABLE,
    SPI_SS0_POLARITY,
};


/* Comm_UART_INIT_STRUCT provides the fields which match the selections
* available in the customizer. Refer to the I2C customizer for detailed
* description of the settings.
*/
const Comm_UART_INIT_STRUCT configUart =
{
    Comm_UART_MODE_STD,     /* mode: Standard */
    Comm_UART_TX_RX,        /* direction: RX + TX */
    UART_DATA_WIDTH,        /* dataBits: 8 bits */
    Comm_UART_PARITY_NONE,  /* parity: None */
    Comm_UART_STOP_BITS_1,  /* stopBits: 1 bit */
    UART_OVERSAMPLING,      /* oversample: 16 */
    DISABLED,               /* enableIrdaLowPower: disabled */
    DISABLED,               /* enableMedianFilter: disabled */
    DISABLED,               /* enableRetryNack: disabled */
    DISABLED,               /* enableInvertedRx: disabled */
    DISABLED,               /* dropOnParityErr: disabled */
    DISABLED,               /* dropOnFrameErr: disabled */
    NON_APPLICABLE,         /* enableWake: disabled */
    UART_RX_BUFFER_SIZE,    /* rxBufferSize: TX software buffer size */
    UART_RX_BUFER_PTR,      /* rxBuffer: pointer to RX software buffer */
    UART_TX_BUFFER_SIZE,    /* txBufferSize: TX software buffer size */
    UART_TX_BUFER_PTR,      /* txBuffer: pointer to TX software buffer */
    DISABLED,               /* enableMultiproc: disabled */
    DISABLED,               /* multiprocAcceptAddr: disabled */
    NON_APPLICABLE,         /* multiprocAddr: N/A */
    NON_APPLICABLE,         /* multiprocAddrMask: N/A */
    ENABLED,                /* enableInterrupt: enable internal interrupt
                             * handler for the software buffer */
    UART_RX_INTR_MASK,      /* rxInterruptMask: enable INTR_RX.NOT_EMPTY to
                             * handle RX software buffer operations */
    NON_APPLICABLE,         /* rxTriggerLevel: N/A */
    UART_TX_INTR_MASK,      /* txInterruptMask: no TX interrupts on start up */
    NON_APPLICABLE,         /* txTriggerLevel: N/A */
    DISABLED,               /* enableByteMode: disabled */
    DISABLED,               /* enableCts: disabled */
    DISABLED,               /* ctsPolarity: disabled */
    DISABLED,               /* rtsRxFifoLevel: disabled */
    DISABLED,               /* rtsPolarity: disabled */
};

/* Global variables to manage current operation mode and initialization state */
uint32 mode = OP_MODE_UART;
uint8 mTxBuffer[4] = {PACKET_SOP, 20, 0, PACKET_EOP};

uint8 cmd1 =0;

/*******************************************************************************
* Function Name: Main
********************************************************************************
* Summary:
*  The main function performs the following actions:
*   1. Sets SCB configuration to UART or I2C.
*   2. Executes UART or I2C example project.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
int main()
{
    CyGlobalIntEnable;

    for(;;)
    {
        /* Set SCB operation mode to UART or I2C. Default mode is UART */
        (void) ConfigurationChange(mode);

        if (OP_MODE_UART == mode)
        {
            /* Execute UART example project */
            RunUartExample();
        }
        else
        {
            /* Execute I2C example project */
            RunSPIExample();
        }
        CyDelay(1000);
       
    }
}


/*******************************************************************************
* Function Name: ConfigurationChange
********************************************************************************
* Summary:
*  This function reconfigures the SCB component between the SPI and UART modes
*  of operation.
*
* Parameters:
*  opMode - mode of operation to which SCB component will be configured.
*
* Return:
*  Returns CYRET_SUCCESS if no problem was encountered while operation mode
*  change or CYRET_BAD_PARAM if unknown operation mode is selected.
*  The valid operation modes are: OP_MODE_I2C and OP_MODE_UART.
*
*******************************************************************************/
static cystatus ConfigurationChange(uint32 opMode)
{
    cystatus status = CYRET_SUCCESS;

    if (OP_MODE_SPI == opMode)
    {
        /***********************************************************************
        * Configure SCB in SPI mode and enable component after completion.
        ***********************************************************************/

        /* Disable component before re-configuration */
        Comm_Stop();

        /* Set clock divider to provide clock frequency to the SCB component
        * to operated with desired data rate.
        */
        CommCLK_SetFractionalDividerRegister(SPI_CLK_DIVIDER, 0u);

        /* Configure SCB component. The configuration is stored in the SPI
        * configuration structure.
        */
        Comm_SpiInit(&configSpi);

      
        /* Put start and end of the packet into the TX buffer */
        bufferTx[PACKET_SOP_POS] = PACKET_SOP;
        bufferTx[PACKET_EOP_POS] = PACKET_EOP;

        /* Start component after re-configuration is complete */
        Comm_Start();
    }
    else if (OP_MODE_UART == opMode)
    {
        /***********************************************************************
        * Configure SCB in UART mode and enable component after completion
        ***********************************************************************/

        /* Disable component before re-configuration */
        Comm_Stop();

        /* Set clock divider to provide clock frequency to the SCB component
        * to operated with desired data rate.
        */
        CommCLK_SetFractionalDividerRegister(UART_CLK_DIVIDER, 0u);

        /* Configure SCB component. The configuration is stored in the UART
        * configuration structure.
        */
        Comm_UartInit(&configUart);

        /* Start component after re-configuration is complete */
        Comm_Start();
    }
    else
    {
        status = CYRET_BAD_PARAM; /* Unknown operation mode - no action */
    }

    return (status);
}


/*******************************************************************************
* Function Name: RunUartExample
********************************************************************************
* Summary:
*  Executes UART example project (SCB_UartComm) until configuration change
*  occurs. The UART example project simply echoes any received character.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
static void RunUartExample(void)
{
    char8 ch;

    LED_BLUE_Write(1);
    LED_GREEN_Write(0); //turn green led on in uart mode

    /* Print start of the example project header in the terminal */
    Comm_UartPutString("\r\n********************************************************************************\r\n");
    Comm_UartPutString("This is SCB_UartComm datasheet example project\r\n");
    Comm_UartPutString("If you are able to read this text the terminal connection is configured\r\n");
    Comm_UartPutString("correctly. Start transmitting the characters to see an echo in the terminal.\r\n");
    Comm_UartPutString("\r\n");

    for(;;)
    {
        /***********************************************************************
        * Loopback (echo) incoming UART characters
        ***********************************************************************/

        
        printf("    cmd1 : %d \r\n",cmd1); //dummy tx to show active uart mode
        CyDelay(200);//delay
        cmd1++;
        
        /* Get received character or zero if nothing has been received yet */
        ch = Comm_UartGetChar();
        if (0u != ch)
        {
            /* Send the data through UART. This function is blocking and waits
            * until there is an entry into the TX FIFO to put the character.
            */
            Comm_UartPutChar(ch);
        }

        /***********************************************************************
        * Change configuration on the switch press event
        ***********************************************************************/
        if (0u != ReadSwSwitch())
        {
            /* Print end of the example project header in the terminal */
            Comm_UartPutString("\r\n********************************************************************************\r\n");
            Comm_UartPutString("SCB_UartComm datasheet example project ends its operation. The mode is changed to SPI\r\n");
            Comm_UartPutString("Connect to SPI slave.\r\n");
            Comm_UartPutString("********************************************************************************\r\n");

            /* Wait until UART completes transfer string */
            CyDelay(WAIT_FOR_END_UART_OUTPUT);

            /* Change configuration to I2C */
            mode = OP_MODE_SPI;
            break;
        }
    }
}


/*******************************************************************************
* Function Name: RunSPIExample
********************************************************************************
* Summary:
*  Executes SPI example project until configuration change
*  occurs.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
static void RunSPIExample(void)
{
    uint8 status;
    LED_BLUE_Write(0); //turn blue led on when in spi mode
    LED_GREEN_Write(1);

    /* Loop until switch is pressed to change configuration */
    for(;;)
    {
        /***********************************************************************
        * Handle master write completion event
        ***********************************************************************/
         /* SPIM TX buffer */

       
        mTxBuffer[1]++; //increase the 2 data bytes
        mTxBuffer[2]++;

        /* Start transfer */
        Comm_SpiUartPutArray(mTxBuffer, 4); //send the data and sop/eop
        CyDelay(100); //delay
   
      
        
        //Comm_SpiUartClearRxBuffer(); //declared here if needed
        //Comm_SpiUartClearTxBuffer();
        /***********************************************************************
        * Change configuration on the switch press event
        ***********************************************************************/
        if (0u != ReadSwSwitch())
        {
            /* Change configuration to UART */
            mode = OP_MODE_UART;
            break;
        }
        
        
    }
}


/*******************************************************************************
* Function Name: ReadSwSwitch
********************************************************************************
* Summary:
*  Reads and returns the current status of the switch.
*
* Parameters:
*  None
*
* Return:
*  Returns non-zero value if switch is pressed and zero otherwise.
*
*******************************************************************************/
static uint32 ReadSwSwitch(void)
{
    uint32 heldDown;
    uint32 swStatus;

    swStatus = 0u;  /* Switch is not active */
    heldDown = 0u;  /* Reset debounce counter */

    /* Wait for debounce period before determining that the switch is pressed */
    while (SWITCH_ON)
    {
        /* Count debounce period */
        CyDelay(SWITCH_DEBOUNCE_UNIT);
        ++heldDown;

        if (heldDown > SWITCH_PUSH)
        {
            swStatus = 1u; /* Switch is pressed */
            break;
        }
    }

    return (swStatus);
}




/* [] END OF FILE */
